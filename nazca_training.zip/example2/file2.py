"""
This example covers slighly more advanced topics.
Topics of this example:

- How to create composite building blocks
- How to put them in a cell
- How to create parametric and reusable building blocks
- How to connect them to other componets
"""

import nazca as nd
import nazca.demofab as demo


# create a iso cell for reuse
iso = demo.isolation_act(length=20)

# define laser cell for reuse
with nd.Cell("dbr_laser") as laser:
    # draw the laser
    demo.dbr(length=30).put(0)
    iso.put()
    demo.soa(length=300).put()
    iso.put()
    demo.phase_shifter(length=50).put()
    iso.put()
    demo.dbr(length=500).put()

# putting multiple laser cells
laser.put(0, 0, 0)
laser.put(0, 500.0, 0)
laser.put(0, 1000.0, 0)


nd.export_gds(filename="mygds.gds")
