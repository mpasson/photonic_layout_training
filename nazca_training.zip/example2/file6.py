"""
This example covers slighly more advanced topics.
Topics of this example:

- How to create composite building blocks
- How to put them in a cell
- How to create parametric and reusable building blocks
- How to connect them to other componets
"""

import nazca as nd

nd.logfile(name=__file__)
import nazca.demofab as demo

# define parametric laser cell for reuse
def dbr_laser(
    front_reflector_length=30.0,
    soa_length=300.0,
    phase_shifter_length=50.0,
    rear_reflector_length=500.0,
    iso_length=20.0,
):
    with nd.Cell("dbr_laser") as laser:
        # create a iso cell for reuse
        iso = demo.isolation_act(length=iso_length)

        # draw the laser
        e1 = demo.dbr(length=front_reflector_length).put(0)
        iso.put()
        e2 = demo.soa(length=soa_length).put()
        iso.put()
        e3 = demo.phase_shifter(length=phase_shifter_length).put()
        iso.put()
        e4 = demo.dbr(length=rear_reflector_length).put()

        # put pins to connect the laser
        nd.Pin("a0", pin=e1.pin["a0"]).put()
        nd.Pin("b0", pin=e4.pin["b0"]).put()
        for i, e in enumerate([e1, e2, e3, e4]):
            nd.Pin(f"c{i}", pin=e.pin["c0"]).put()

        # show laser pins on gds
        nd.put_stub()
    return laser


las = dbr_laser().put(0, 0, 0)
demo.a2s().put()
demo.shallow.strt(200.0).put()

for i in range(4):
    demo.metaldc.strt(500.0).put(las.pin[f"c{i}"])

nd.export_gds(filename="mygds.gds")
