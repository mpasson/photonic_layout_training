"""
This example covers slightly more advanced topics.
Topics of this example:

- How to create custom cross section and interconnects
- Introduction to a PDK custom xsections and interconnects
"""

import nazca as nd
from nazca.interconnects import Interconnect

# creating layer entries in nazca
nd.add_layer(name="LiNbO3 Waveguide", layer=(2, 0))
nd.add_layer(name="LiNbO3 ShallowTrench", layer=(2, 1))

# creating xsection object and populating it with layers
xs_shallow = nd.add_xsection("Shallow")
nd.add_layer2xsection(xsection="Shallow", layer="LiNbO3 Waveguide", growx=0.0)
nd.add_layer2xsection(xsection="Shallow", layer="LiNbO3 ShallowTrench", growx=7.0)

# assign other properties to the cross-section
xs_shallow = nd.add_xsection("Waveguide")  # create (or reuse) a xsection object
xs_shallow.os = 0.0  #  set straight-to-bend-offset
xs_shallow.width = 1.0  # set default width
xs_shallow.radius = 200.0  # set default radius
xs_shallow.minimum_radius = 200.0  # DRC: set minimum allowed radius
xs_shallow.taper = 50.0  #  set default taper length

# defining an interconnect object with the newly created cross-section
shallow = Interconnect(xs="Shallow")

# using the interconnect
shallow.strt(100.0).put()

nd.export_gds()
