This folder contains example files illustrating some nazca features

The summary of the examples is the following:

Example 0:
    This example is a toy example. It only illustrates how easy it is with nazca to go from script to a gds file.

Example 1:
    This example covers the basic of components placing and connections

Example 2:
    This example covers the creation on a cell and the use in hierarchical design.
    It also cover the creation of parametric cells

Example 3:
    This example covers the creation of custom cross sections.