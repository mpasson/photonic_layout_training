"""
This example covers the basics.
Topics of this example:

- How to import nazca
- How to import a PDK
- How to use blocks from PDK
- How to place cells
- How to use interconnects from PDK
- How to export a GDS
"""

import numpy as np

import nazca as nd
import nazca.demofab as demo


mmi = demo.mmi1x2_dp()

# putting multiple mmi in chain
mmi.put()
mmi.put()

# put mmis at specific points
mmi.put(0.0, 100.0, 0.0)
mmi.put(0.0, 200.0, 45.0)

# put specific pin on mmi at specific point
mmi.put("b0", 0.0, 300.0, 45.0)

nd.export_gds(filename="mygds.gds")
