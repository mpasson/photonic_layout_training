"""
This example covers the basics.
Topics of this example:

- How to import nazca
- How to import a PDK
- How to use blocks from PDK
- How to place cells
- How to use interconnects from PDK
- How to export a GDS
"""

import numpy as np

import nazca as nd
import nazca.demofab as demo


mmi = demo.mmi1x2_dp()

# putting mmi inistance and giving it a name
mmi1 = mmi.put()

# putting mmi instance on specific pin on another
mmi2 = mmi.put(mmi1.pin["a0"])

# the same, but moving mmi instance pin before
mmi1 = mmi.put(0.0, 200.0)
mmi2 = mmi.put(mmi1.pin["a0"].move(100.0, 50.0, 45.0))


nd.export_gds(filename="mygds.gds")
