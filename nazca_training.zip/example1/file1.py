"""
This example covers the basics.
Topics of this example:

- How to import nazca
- How to import a PDK
- How to use blocks from PDK
- How to place cells
- How to use interconnects from PDK
- How to export a GDS
"""

import numpy as np

import nazca as nd
import nazca.demofab as demo

# putting a sinle mmi
demo.mmi1x2_dp().put()

nd.export_gds(filename="mygds.gds")
