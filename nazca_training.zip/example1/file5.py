"""
This example covers the basics.
Topics of this example:

- How to import nazca
- How to import a PDK
- How to use blocks from PDK
- How to place cells
- How to use interconnects from PDK
- How to export a GDS
"""

import numpy as np

import nazca as nd
import nazca.demofab as demo


mmi = demo.mmi1x2_dp()

# putting 3 mmis
mmi1 = mmi.put()
mmi2 = mmi.put(400.0, 100.0, 0.0)
mmi3 = mmi.put(500.0, -200.0, 0.0)


# connecting mmis with
demo.deep.sbend_p2p(mmi1.pin["b0"], mmi2.pin["a0"]).put()
demo.deep.sbend_p2p(mmi1.pin["b1"], mmi3.pin["a0"]).put()


nd.export_gds(filename="mygds.gds")
