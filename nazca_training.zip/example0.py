import nazca as nd

house = [(0.0, 0.0), (0.0, 1.0), (0.5, 1.5), (1.0, 1.0), (1.0, 0.0)]
nd.Polygon(points=house, layer=1).put()
nd.export_gds()
